# Miku AI 🎤✨

Asisten suara ala Jarvis berbasis Flutter:
- **Buka aplikasi lewat suara** — contoh: *"buka whatsapp"*, *"buka youtube"*.
- **Membaca chat masuk** (WhatsApp, Telegram, Messenger, SMS) — Miku otomatis membacakan notifikasi baru pakai suara.
- **Membalas chat lewat suara** — tekan tombol "Balas dengan suara" pada chat, ucapkan balasanmu, Miku mengirimkannya lewat tombol *quick-reply* asli aplikasi tsb (tanpa perlu membuka aplikasinya).
- **Icon app custom** dari gambar Miku yang kamu kirim.

> ⚠️ Project ini adalah **source code lengkap**, bukan file `.apk` jadi. Untuk mengubahnya jadi APK, kamu perlu build sendiri di komputer (lihat langkah di bawah) karena proses build butuh Android SDK + Flutter SDK yang tidak tersedia di lingkungan chat ini.

---

## 1. Yang perlu disiapkan di komputermu

1. **Flutter SDK** (versi stabil terbaru) — https://docs.flutter.dev/get-started/install
2. **Android Studio** (untuk Android SDK & emulator/device) — https://developer.android.com/studio
3. HP Android asli lebih disarankan daripada emulator, karena fitur baca/balas notifikasi butuh notifikasi sungguhan dari WhatsApp dsb.

Cek instalasi:
```bash
flutter doctor
```
Pastikan semua tanda centang hijau (minimal untuk Android).

## 2. Menyiapkan project

1. Ekstrak folder `miku_ai` ini.
2. Salin `android/local.properties.example` menjadi `android/local.properties`, lalu isi path SDK sesuai komputermu.
3. Install dependency:
   ```bash
   cd miku_ai
   flutter pub get
   ```
4. Colokkan HP Android (aktifkan USB debugging) atau jalankan emulator.

## 3. Menjalankan / build APK

Jalankan langsung ke device untuk testing:
```bash
flutter run
```

Build APK release untuk diinstal manual:
```bash
flutter build apk --release
```
File APK akan muncul di:
```
build/app/outputs/flutter-apk/app-release.apk
```
Salin file itu ke HP dan install seperti biasa (aktifkan "Install dari sumber tidak dikenal" jika diminta).

## 4. Izin yang wajib diaktifkan manual di HP

Setelah install & buka aplikasinya:

1. **Izin Microphone** — akan muncul dialog otomatis saat pertama buka app.
2. **Akses Notifikasi (Notification Access)** — ini WAJIB untuk fitur baca/balas chat. Di dalam app akan muncul banner "Aktifkan Sekarang" yang otomatis membuka halaman:
   `Settings > Apps > Special app access > Notification access` → aktifkan **Miku AI**.
   Tanpa izin ini, Miku tidak bisa membaca notifikasi WhatsApp sama sekali (ini batasan keamanan Android, bukan bug).
3. Untuk membuka aplikasi lain via suara di **Android 11 ke atas**, permission `QUERY_ALL_PACKAGES` sudah didaftarkan di manifest — cukup pastikan kamu tidak menghapusnya saat submit ke Play Store (Play Store mewajibkan penjelasan tambahan untuk permission ini kalau mau publish publik).

## 5. Cara kerja fitur "baca & balas chat WhatsApp" (teknis)

- `MikuNotificationListener.kt` adalah `NotificationListenerService` bawaan Android yang menyadap notifikasi masuk dari package `com.whatsapp` (dan beberapa app chat lain, bisa ditambah di `CHAT_PACKAGES`).
- Saat notifikasi baru muncul, judul & isi pesan dikirim ke Flutter lewat `EventChannel`, lalu Miku membacakannya via `flutter_tts`.
- WhatsApp (dan kebanyakan app chat modern) menyertakan **tombol "Balas Cepat"** di notifikasinya, yang secara teknis adalah `Notification.Action` berisi `RemoteInput`. Kode kita mengambil action itu, lalu saat kamu bicara balasan, teks hasil `speech_to_text` dimasukkan ke `RemoteInput` itu dan dikirim — persis seperti cara jam tangan (Wear OS) membalas chat. **Tidak perlu accessibility service** dan tidak menyentuh UI WhatsApp sama sekali.
- Kalau notifikasi tertentu tidak punya tombol balas cepat, tombol "Balas dengan suara" tidak akan muncul untuk chat itu (`canReply: false`).

### Menambah aplikasi chat lain
Edit `CHAT_PACKAGES` di:
```
android/app/src/main/kotlin/com/mikuai/assistant/MikuNotificationListener.kt
```

## 6. Membuka aplikasi via suara (teknis)

`AppLauncherService` (`lib/services/app_launcher_service.dart`) memakai package `device_apps` untuk:
1. Mengambil daftar semua aplikasi terinstal yang punya launcher icon.
2. Mencocokkan ucapan user (setelah kata "buka"/"jalankan"/dst dibuang) dengan nama aplikasi.
3. Memanggil `DeviceApps.openApp(packageName)`.

## 7. Struktur project

```
miku_ai/
├── lib/
│   ├── main.dart
│   ├── models/chat_message.dart
│   ├── services/
│   │   ├── voice_service.dart          # speech-to-text + text-to-speech
│   │   ├── app_launcher_service.dart   # buka app via suara
│   │   └── notification_bridge.dart    # jembatan ke kode native Android
│   ├── screens/home_screen.dart
│   └── widgets/chat_bubble.dart
├── android/
│   └── app/src/main/kotlin/com/mikuai/assistant/
│       ├── MainActivity.kt             # MethodChannel & EventChannel
│       └── MikuNotificationListener.kt # sadap & balas notifikasi
└── assets/icon/                        # icon Miku AI (dari gambar yang kamu upload)
```

## 8. Batasan & ide pengembangan lanjutan

- **Belum ada "wake word"** (mis. "Hai Miku") yang selalu mendengarkan di background — saat ini mic diaktifkan manual dengan tombol, karena fitur *always-listening* butuh foreground service + engine wake-word (mis. Porcupine) yang cukup kompleks untuk ditambahkan belakangan.
- Pencocokan nama aplikasi masih sederhana (contains-match) — bisa ditingkatkan dengan fuzzy matching (mis. package `string_similarity`).
- Beberapa versi WhatsApp/OEM (Xiaomi, Oppo, dll dengan MIUI/ColorOS) kadang membatasi notification listener di background — mungkin perlu menambahkan app ke "protected apps"/battery optimization whitelist di HP tersebut.
- `applicationId` di `android/app/build.gradle` masih `com.mikuai.assistant` — ganti ke ID unikmu sebelum publish ke Play Store.
- Icon sumber yang kamu kirim beresolusi kecil (72×72px), jadi hasil di layar HD (`xxxhdpi`) akan sedikit buram. Kalau punya versi resolusi lebih tinggi (disarankan 512×512px), ganti file di `assets/icon/app_icon_512.png` lalu generate ulang mipmap-nya.

Selamat mengembangkan Miku AI! 🩵
