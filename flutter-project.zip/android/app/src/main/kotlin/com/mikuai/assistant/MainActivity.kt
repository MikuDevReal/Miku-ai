package com.mikuai.assistant

import android.content.ComponentName
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val METHOD_CHANNEL = "miku_ai/notifications"
    private val EVENT_CHANNEL = "miku_ai/notifications_stream"

    companion object {
        // sink event channel yang aktif, dipakai NotificationListener untuk mengirim event
        private var eventSink: EventChannel.EventSink? = null

        fun sendNotificationEvent(data: Map<String, Any?>) {
            eventSink?.success(data)
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, METHOD_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "hasNotificationAccess" -> {
                        result.success(isNotificationServiceEnabled())
                    }
                    "openNotificationAccessSettings" -> {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        result.success(null)
                    }
                    "sendReply" -> {
                        val id = call.argument<Int>("id") ?: -1
                        val text = call.argument<String>("text") ?: ""
                        val ok = MikuNotificationListener.instance?.sendReply(id, text) ?: false
                        result.success(ok)
                    }
                    "listInstalledApps" -> {
                        result.success(listInstalledApps())
                    }
                    "launchApp" -> {
                        val pkg = call.argument<String>("package")
                        val ok = if (pkg != null) launchApp(pkg) else false
                        result.success(ok)
                    }
                    else -> result.notImplemented()
                }
            }

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, EVENT_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, sink: EventChannel.EventSink?) {
                    eventSink = sink
                }

                override fun onCancel(arguments: Any?) {
                    eventSink = null
                }
            })
    }

    /**
     * Daftar aplikasi terinstal yang punya launcher icon (bisa dibuka user),
     * dipakai Flutter untuk mencocokkan perintah suara "buka <nama app>".
     * Menggantikan paket pihak ketiga (device_apps) yang sudah tidak
     * kompatibel dengan Android Gradle Plugin versi baru.
     */
    private fun listInstalledApps(): List<Map<String, String>> {
        val pm = applicationContext.packageManager
        val launchableApps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
            0,
        )

        return launchableApps.mapNotNull { resolveInfo ->
            try {
                val pkg = resolveInfo.activityInfo.packageName
                val label = resolveInfo.loadLabel(pm).toString()
                mapOf("appName" to label, "packageName" to pkg)
            } catch (e: Exception) {
                null
            }
        }.distinctBy { it["packageName"] }
    }

    private fun launchApp(packageName: String): Boolean {
        val intent = applicationContext.packageManager.getLaunchIntentForPackage(packageName)
            ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val pkgName = packageName
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        if (flat.isNullOrEmpty()) return false
        for (name in flat.split(":")) {
            val cn = ComponentName.unflattenFromString(name)
            if (cn != null && cn.packageName == pkgName) return true
        }
        return false
    }
}
