package com.mikuai.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Menyadap notifikasi yang masuk ke sistem Android (mis. WhatsApp, Telegram, SMS),
 * lalu meneruskannya ke Flutter lewat EventChannel (dijembatani oleh MainActivity),
 * dan menyimpan aksi "balas cepat" (RemoteInput) tiap notifikasi supaya Flutter
 * bisa mengirim balasan suara tanpa perlu membuka aplikasi aslinya.
 *
 * Daftar package yang dianggap "chat" bisa ditambah sesuai kebutuhan.
 */
class MikuNotificationListener : NotificationListenerService() {

    companion object {
        // Instance aktif service ini, dipakai MainActivity untuk memanggil sendReply().
        var instance: MikuNotificationListener? = null

        // package aplikasi chat yang ingin dipantau
        val CHAT_PACKAGES = setOf(
            "com.whatsapp",
            "com.whatsapp.w4b",
            "org.telegram.messenger",
            "com.facebook.orca", // messenger
            "com.google.android.apps.messaging", // SMS bawaan Google
        )

        const val EXTRA_APP_NAME_UNKNOWN = "Chat"
    }

    // notificationId -> RemoteInput action milik notifikasi itu, supaya bisa dibalas nanti
    private val replyableActions = HashMap<Int, Pair<Notification.Action, StatusBarNotification>>()

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg !in CHAT_PACKAGES) return

        val notification = sbn.notification
        val extras: Bundle = notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: EXTRA_APP_NAME_UNKNOWN
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        if (text.isBlank()) return

        // cari action "Balas" / "Reply" yang punya RemoteInput
        val replyAction = notification.actions?.firstOrNull { action ->
            action.remoteInputs?.isNotEmpty() == true
        }

        val canReply = replyAction != null
        if (replyAction != null) {
            replyableActions[sbn.id] = Pair(replyAction, sbn)
        }

        val appName = try {
            val pm = applicationContext.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

        MainActivity.sendNotificationEvent(
            mapOf(
                "id" to sbn.id,
                "package" to pkg,
                "appName" to appName,
                "title" to title,
                "text" to text,
                "canReply" to canReply,
            )
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        replyableActions.remove(sbn.id)
    }

    /**
     * Mengirim balasan lewat quick-reply action asli milik notifikasi (RemoteInput),
     * persis seperti balas cepat dari jam tangan / notification shade.
     */
    fun sendReply(notificationId: Int, replyText: String): Boolean {
        val pair = replyableActions[notificationId] ?: return false
        val (action, _) = pair
        val remoteInputs = action.remoteInputs ?: return false

        val resultIntent = Intent()
        val bundle = Bundle()
        for (ri in remoteInputs) {
            bundle.putCharSequence(ri.resultKey, replyText)
        }
        RemoteInput.addResultsToIntent(remoteInputs, resultIntent, bundle)

        return try {
            action.actionIntent.send(applicationContext, 0, resultIntent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
