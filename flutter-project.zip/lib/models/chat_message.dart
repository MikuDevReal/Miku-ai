class ChatMessage {
  final int id; // notification id, dipakai untuk kirim balasan
  final String appPackage;
  final String appName;
  final String sender; // judul notifikasi, biasanya nama kontak
  final String text;
  final bool canReply; // apakah notifikasi ini punya quick-reply action
  final DateTime time;
  bool isRead;

  ChatMessage({
    required this.id,
    required this.appPackage,
    required this.appName,
    required this.sender,
    required this.text,
    required this.canReply,
    DateTime? time,
    this.isRead = false,
  }) : time = time ?? DateTime.now();

  factory ChatMessage.fromMap(Map<dynamic, dynamic> map) {
    return ChatMessage(
      id: map['id'] as int? ?? 0,
      appPackage: map['package'] as String? ?? '',
      appName: map['appName'] as String? ?? '',
      sender: map['title'] as String? ?? 'Tidak dikenal',
      text: map['text'] as String? ?? '',
      canReply: map['canReply'] as bool? ?? false,
    );
  }
}
