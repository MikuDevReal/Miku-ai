import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/chat_message.dart';
import '../services/app_launcher_service.dart';
import '../services/notification_bridge.dart';
import '../services/voice_service.dart';
import '../widgets/chat_bubble.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  final VoiceService _voice = VoiceService();
  final AppLauncherService _launcher = AppLauncherService();
  final NotificationBridge _notifications = NotificationBridge();

  final List<ChatMessage> _messages = [];
  String _statusText = 'Menyiapkan mic...';

  // _listening: true selagi satu sesi speech-to-text sedang aktif (untuk
  // animasi ikon). _paused: mode dengar-terus dijeda manual oleh user (tap
  // FAB) atau otomatis kalau mic benar-benar tidak tersedia.
  bool _listening = false;
  bool _paused = true;
  // true selagi Miku lagi bicara (TTS) - dipakai supaya siklus dengar-terus
  // tidak langsung membuka sesi mic baru sementara Miku masih ngomong
  // (menghindari dia "dengar" suaranya sendiri).
  bool _busySpeaking = false;

  bool _notifAccessGranted = false;

  List<Map<String, String>> _voices = [];
  Map<String, String>? _selectedVoice;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    final micStatus = await Permission.microphone.request();
    final ready = await _voice.init();
    final micOk = ready && micStatus.isGranted;

    _paused = !micOk;
    _statusText = micOk
        ? 'Mendengarkan otomatis... ucapkan "hey miku" lalu perintahnya'
        : (micStatus.isPermanentlyDenied
            ? 'Izin mikrofon ditolak permanen. Aktifkan manual lewat Pengaturan > Aplikasi > Miku AI > Izin.'
            : 'Izin mikrofon belum aktif, ketuk mic untuk mencoba lagi.');

    _voices = await _voice.getAvailableVoices();
    _notifAccessGranted = await _notifications.hasNotificationAccess();
    if (mounted) setState(() {});

    // Dengarkan notifikasi chat baru (WhatsApp, dll) dari native.
    _notifications.onNewMessage.listen((msg) async {
      if (!mounted) return;
      setState(() => _messages.insert(0, msg));
      _busySpeaking = true;
      await _voice.speak('Pesan baru dari ${msg.sender}. ${msg.text}');
      _busySpeaking = false;
    });

    // Begitu izin mic aktif, langsung mulai mode "selalu mendengarkan" -
    // tidak perlu tap tombol dulu. Sistem akan diam total kecuali dengar
    // kata panggil "hey miku".
    if (micOk) {
      _listenCycle();
    }
  }

  /// Loop dengar-terus: buka satu sesi mic, tunggu sampai selesai (dapat
  /// hasil / error / hening), proses hasilnya, lalu buka sesi berikutnya -
  /// terus begitu selama tidak di-pause. Berhenti sendiri kalau mic memang
  /// tidak tersedia.
  Future<void> _listenCycle() async {
    if (!mounted || _paused || _listening) return;

    if (_busySpeaking) {
      // Miku lagi ngomong, tunda sebentar biar tidak dengar suaranya sendiri.
      Future.delayed(const Duration(milliseconds: 300), _listenCycle);
      return;
    }

    setState(() => _listening = true);

    await _voice.listenOnce(
      onPartial: (p) {
        if (mounted && !_paused) {
          setState(() => _statusText = p.isEmpty ? _statusText : 'Dengar: $p');
        }
      },
      onResult: (text) async {
        await _handleWakeWordCommand(text);
      },
      onUnavailable: (reason) {
        if (!mounted) return;
        setState(() {
          _statusText = reason;
          _paused = true; // mic memang tidak tersedia, hentikan loop
        });
      },
      onError: (_) {
        // Di mode dengar-terus, "tidak ada suara cocok" / timeout itu WAJAR
        // (kebanyakan suara sekitar bukan perintah) - diamkan saja, jangan
        // spam status/TTS tiap kali ini terjadi.
      },
    );

    if (!mounted) return;
    setState(() => _listening = false);

    if (!_paused) {
      // Sesi ini sudah benar-benar selesai (listenOnce menunggunya) -
      // aman untuk langsung buka sesi berikutnya.
      Future.delayed(const Duration(milliseconds: 400), _listenCycle);
    }
  }

  void _toggleListening() {
    if (_paused) {
      setState(() {
        _paused = false;
        _statusText = 'Mendengarkan otomatis... ucapkan "hey miku" lalu perintahnya';
      });
      _listenCycle();
    } else {
      setState(() {
        _paused = true;
        _statusText = 'Mic dijeda. Ketuk lagi untuk lanjut mendengarkan.';
      });
      _voice.stopListening();
    }
  }

  /// Gerbang wake-word: teks yang tidak mengandung "miku" DIABAIKAN TOTAL -
  /// tidak ada respons, tidak ada bunyi, tidak ada perubahan status. Sistem
  /// cuma bereaksi kalau dengar nama panggilannya.
  ///
  /// Catatan: yang dicek cuma kata "miku" (bukan "hey miku" lengkap), karena
  /// speech recognizer di-set locale Indonesia (id-ID) dan sering salah
  /// dengar kata Inggris "hey" - tapi "miku" sendiri biasanya cukup akurat
  /// tertangkap.
  Future<void> _handleWakeWordCommand(String text) async {
    if (text.trim().isEmpty) return;

    final normalized = text
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9 ]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    final mikuIndex = normalized.indexOf('miku');
    if (mikuIndex == -1) {
      // Bukan wake word -> diam, lanjut dengar seperti biasa.
      return;
    }

    final command = normalized.substring(mikuIndex + 'miku'.length).trim();

    if (command.isEmpty) {
      // Cuma manggil nama tanpa perintah lanjutan.
      if (mounted) setState(() => _statusText = 'Ya bos, siap!');
      _busySpeaking = true;
      await _voice.speak('Ya bos');
      _busySpeaking = false;
      return;
    }

    if (command.contains('buka') ||
        command.contains('jalankan') ||
        command.contains('nyalakan')) {
      if (mounted) setState(() => _statusText = 'Ya bos, siap!');
      _busySpeaking = true;
      await _voice.speak('Siap bos');
      _busySpeaking = false;

      try {
        final opened = await _launcher.openAppFromCommand(command);
        if (opened != null) {
          if (mounted) setState(() => _statusText = 'Membuka $opened...');
          _busySpeaking = true;
          await _voice.speak('Membuka $opened');
          _busySpeaking = false;
        } else {
          final detail = _launcher.lastError;
          if (mounted) {
            setState(() => _statusText = detail != null
                ? 'Gagal: $detail'
                : 'Aplikasi tidak ditemukan: "$command"');
          }
          _busySpeaking = true;
          await _voice.speak('Maaf, aplikasi tidak ditemukan');
          _busySpeaking = false;
        }
      } catch (e) {
        if (mounted) setState(() => _statusText = 'Error saat buka aplikasi: $e');
        _busySpeaking = true;
        await _voice.speak('Maaf, terjadi kesalahan saat membuka aplikasi');
        _busySpeaking = false;
      }
      return;
    }

    // Ada wake word tapi perintah setelahnya belum dikenali.
    if (mounted) {
      setState(() => _statusText = 'Ya bos? Perintah belum dikenali: "$command"');
    }
    _busySpeaking = true;
    await _voice.speak('Maaf, aku belum mengerti perintah itu');
    _busySpeaking = false;
  }

  String _friendlySpeechError(String rawError) {
    switch (rawError) {
      case 'error_no_match':
        return 'Suara tidak dikenali. Coba bicara lebih jelas/pelan.';
      case 'error_speech_timeout':
        return 'Tidak ada suara terdengar, coba lagi.';
      case 'error_network':
      case 'error_network_timeout':
        return 'Speech recognition butuh koneksi internet, cek koneksimu.';
      case 'error_audio':
        return 'Gagal mengakses mic, coba lagi.';
      default:
        return 'Error mic: $rawError';
    }
  }

  Future<void> _openVoiceSettings() async {
    if (_voices.isEmpty) {
      _voices = await _voice.getAvailableVoices(localeFilter: null);
    }
    if (!mounted) return;

    await showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0A1526),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Pilih Suara Miku',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
              if (_voices.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Tidak ada suara tambahan yang terdeteksi di perangkat ini.',
                    style: TextStyle(color: Colors.white54),
                  ),
                ),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _voices.length,
                  itemBuilder: (context, i) {
                    final v = _voices[i];
                    final selected = _selectedVoice?['name'] == v['name'];
                    return ListTile(
                      title: Text(
                        v['name'] ?? '',
                        style: const TextStyle(color: Colors.white),
                      ),
                      subtitle: Text(
                        v['locale'] ?? '',
                        style: const TextStyle(color: Colors.white54),
                      ),
                      trailing: selected
                          ? const Icon(Icons.check, color: Color(0xFF35D0FF))
                          : IconButton(
                              icon: const Icon(Icons.volume_up,
                                  color: Colors.white54),
                              onPressed: () =>
                                  _voice.speak('Halo, ini contoh suara Miku'),
                            ),
                      onTap: () async {
                        await _voice.setVoice(v);
                        setState(() => _selectedVoice = v);
                        if (context.mounted) Navigator.pop(context);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _onReplyTap(ChatMessage message) async {
    // Jeda sementara mode dengar-terus supaya tidak rebutan mic dengan sesi
    // dikte balasan ini, lalu lanjutkan lagi setelah selesai.
    final wasPaused = _paused;
    _paused = true;
    await _voice.stopListening();

    setState(() => _statusText = 'Ucapkan balasan untuk ${message.sender}...');

    await _voice.listenOnce(
      onPartial: (p) => setState(() => _statusText = p),
      onResult: (replyText) async {
        if (replyText.trim().isEmpty) return;

        final ok = await _notifications.sendReply(
          notificationId: message.id,
          appPackage: message.appPackage,
          replyText: replyText,
        );

        setState(() {
          _statusText = ok
              ? 'Balasan terkirim ke ${message.sender}'
              : 'Gagal mengirim balasan';
        });
        _busySpeaking = true;
        await _voice.speak(ok ? 'Balasan terkirim' : 'Maaf, balasan gagal terkirim');
        _busySpeaking = false;
      },
      onUnavailable: (reason) => setState(() => _statusText = reason),
      onError: (error) => setState(() => _statusText = _friendlySpeechError(error)),
    );

    if (!wasPaused && mounted) {
      _paused = false;
      _listenCycle();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF060B16),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A1526),
        elevation: 0,
        title: const Text(
          'MIKU AI',
          style: TextStyle(
            color: Color(0xFF35D0FF),
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.record_voice_over, color: Colors.white70),
            tooltip: 'Ganti suara Miku',
            onPressed: _openVoiceSettings,
          ),
        ],
      ),
      body: Column(
        children: [
          if (!_notifAccessGranted) _buildNotificationAccessBanner(),
          Expanded(
            child: _messages.isEmpty
                ? const Center(
                    child: Text(
                      'Belum ada chat masuk.\nMiku akan membacakan pesan baru di sini.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white38),
                    ),
                  )
                : ListView.builder(
                    itemCount: _messages.length,
                    itemBuilder: (context, i) => ChatBubble(
                      message: _messages[i],
                      onReplyTap: () => _onReplyTap(_messages[i]),
                    ),
                  ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            child: Text(
              _statusText,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton.large(
        backgroundColor: _paused
            ? Colors.white24
            : (_listening ? const Color(0xFFFF4FA0) : const Color(0xFF35D0FF)),
        onPressed: _toggleListening,
        tooltip: _paused ? 'Ketuk untuk mulai dengar otomatis' : 'Ketuk untuk jeda',
        child: Icon(
          _paused ? Icons.mic_off : (_listening ? Icons.hearing : Icons.mic),
          size: 32,
          color: Colors.black,
        ),
      ),
    );
  }

  Widget _buildNotificationAccessBanner() {
    return Container(
      width: double.infinity,
      color: const Color(0xFFFF4FA0).withOpacity(0.15),
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          const Text(
            'Miku butuh izin "Akses Notifikasi" untuk bisa membaca & membalas chat.',
            style: TextStyle(color: Colors.white),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          ElevatedButton(
            onPressed: () async {
              await _notifications.openNotificationAccessSettings();
              final granted = await _notifications.hasNotificationAccess();
              setState(() => _notifAccessGranted = granted);
            },
            child: const Text('Aktifkan Sekarang'),
          ),
        ],
      ),
    );
  }
}
