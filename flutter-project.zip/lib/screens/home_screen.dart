import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/chat_message.dart';
import '../services/app_launcher_service.dart';
import '../services/notification_bridge.dart';
import '../services/voice_service.dart';
import '../widgets/chat_bubble.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  final VoiceService _voice = VoiceService();
  final AppLauncherService _launcher = AppLauncherService();
  final NotificationBridge _notifications = NotificationBridge();

  final List<ChatMessage> _messages = [];
  String _statusText = 'Ketuk mic lalu ucapkan perintah, contoh: "buka whatsapp"';
  bool _busy = false;
  bool _notifAccessGranted = false;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  List<Map<String, String>> _voices = [];
  Map<String, String>? _selectedVoice;

  Future<void> _bootstrap() async {
    final micStatus = await Permission.microphone.request();
    final ready = await _voice.init();

    if (!ready || !micStatus.isGranted) {
      _statusText = micStatus.isPermanentlyDenied
          ? 'Izin mikrofon ditolak permanen. Aktifkan manual lewat Pengaturan > Aplikasi > Miku AI > Izin.'
          : 'Izin mikrofon belum aktif, ketuk mic untuk mencoba lagi.';
    }

    _voices = await _voice.getAvailableVoices();

    _notifAccessGranted = await _notifications.hasNotificationAccess();
    setState(() {});

    // Dengarkan notifikasi chat baru (WhatsApp, dll) dari native.
    _notifications.onNewMessage.listen((msg) async {
      setState(() => _messages.insert(0, msg));
      await _voice.speak('Pesan baru dari ${msg.sender}. ${msg.text}');
    });
  }

  Future<void> _onMicPressed() async {
    if (_voice.isListening) {
      await _voice.stopListening();
      return;
    }

    // Kalau izin mic belum ada, minta lagi di sini juga (bukan cuma sekali
    // saat app pertama dibuka), lalu jelaskan ke user kalau masih ditolak.
    final micStatus = await Permission.microphone.status;
    if (!micStatus.isGranted) {
      final result = await Permission.microphone.request();
      if (!result.isGranted) {
        setState(() {
          _busy = false;
          _statusText = result.isPermanentlyDenied
              ? 'Izin mic ditolak permanen. Aktifkan manual lewat Pengaturan HP.'
              : 'Izin mic dibutuhkan supaya perintah suara bisa jalan.';
        });
        if (result.isPermanentlyDenied) {
          await openAppSettings();
        }
        return;
      }
    }

    setState(() {
      _busy = true;
      _statusText = 'Mendengarkan...';
    });

    final started = await _voice.listenOnce(
      onPartial: (partial) => setState(() => _statusText = partial),
      onResult: (finalText) => _handleCommand(finalText),
      onUnavailable: (reason) {
        setState(() {
          _busy = false;
          _statusText = reason;
        });
      },
    );

    // Jaga-jaga: kalau listen gagal start tapi onUnavailable tidak sempat
    // dipanggil, jangan biarkan UI nyangkut di "Mendengarkan...".
    if (!started && _busy) {
      setState(() {
        _busy = false;
        _statusText = 'Gagal memulai mic, coba lagi.';
      });
    }
  }

  Future<void> _openVoiceSettings() async {
    if (_voices.isEmpty) {
      _voices = await _voice.getAvailableVoices(localeFilter: null);
    }
    if (!mounted) return;

    await showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0A1526),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Pilih Suara Miku',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
              if (_voices.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Tidak ada suara tambahan yang terdeteksi di perangkat ini.',
                    style: TextStyle(color: Colors.white54),
                  ),
                ),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _voices.length,
                  itemBuilder: (context, i) {
                    final v = _voices[i];
                    final selected = _selectedVoice?['name'] == v['name'];
                    return ListTile(
                      title: Text(
                        v['name'] ?? '',
                        style: const TextStyle(color: Colors.white),
                      ),
                      subtitle: Text(
                        v['locale'] ?? '',
                        style: const TextStyle(color: Colors.white54),
                      ),
                      trailing: selected
                          ? const Icon(Icons.check, color: Color(0xFF35D0FF))
                          : IconButton(
                              icon: const Icon(Icons.volume_up,
                                  color: Colors.white54),
                              onPressed: () =>
                                  _voice.speak('Halo, ini contoh suara Miku'),
                            ),
                      onTap: () async {
                        await _voice.setVoice(v);
                        setState(() => _selectedVoice = v);
                        if (context.mounted) Navigator.pop(context);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _handleCommand(String text) async {
    setState(() => _busy = false);
    if (text.trim().isEmpty) {
      setState(() => _statusText = 'Tidak menangkap suara apapun, coba lagi.');
      return;
    }

    final lower = text.toLowerCase();

    if (lower.contains('buka') || lower.contains('jalankan') || lower.contains('nyalakan')) {
      final opened = await _launcher.openAppFromCommand(text);
      if (opened != null) {
        setState(() => _statusText = 'Membuka $opened...');
        await _voice.speak('Membuka $opened');
      } else {
        setState(() => _statusText = 'Aplikasi tidak ditemukan: "$text"');
        await _voice.speak('Maaf, aplikasi tidak ditemukan');
      }
      return;
    }

    setState(() => _statusText = 'Perintah tidak dikenali: "$text"');
    await _voice.speak('Maaf, aku belum mengerti perintah itu');
  }

  Future<void> _onReplyTap(ChatMessage message) async {
    setState(() => _statusText = 'Ucapkan balasan untuk ${message.sender}...');

    await _voice.listenOnce(
      onPartial: (p) => setState(() => _statusText = p),
      onResult: (replyText) async {
        if (replyText.trim().isEmpty) return;

        final ok = await _notifications.sendReply(
          notificationId: message.id,
          appPackage: message.appPackage,
          replyText: replyText,
        );

        setState(() {
          _statusText = ok
              ? 'Balasan terkirim ke ${message.sender}'
              : 'Gagal mengirim balasan';
        });
        await _voice.speak(ok ? 'Balasan terkirim' : 'Maaf, balasan gagal terkirim');
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF060B16),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A1526),
        elevation: 0,
        title: const Text(
          'MIKU AI',
          style: TextStyle(
            color: Color(0xFF35D0FF),
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.record_voice_over, color: Colors.white70),
            tooltip: 'Ganti suara Miku',
            onPressed: _openVoiceSettings,
          ),
        ],
      ),
      body: Column(
        children: [
          if (!_notifAccessGranted) _buildNotificationAccessBanner(),
          Expanded(
            child: _messages.isEmpty
                ? const Center(
                    child: Text(
                      'Belum ada chat masuk.\nMiku akan membacakan pesan baru di sini.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white38),
                    ),
                  )
                : ListView.builder(
                    itemCount: _messages.length,
                    itemBuilder: (context, i) => ChatBubble(
                      message: _messages[i],
                      onReplyTap: () => _onReplyTap(_messages[i]),
                    ),
                  ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            child: Text(
              _statusText,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton.large(
        backgroundColor:
            _busy ? const Color(0xFFFF4FA0) : const Color(0xFF35D0FF),
        onPressed: _onMicPressed,
        child: Icon(_busy ? Icons.hearing : Icons.mic, size: 32, color: Colors.black),
      ),
    );
  }

  Widget _buildNotificationAccessBanner() {
    return Container(
      width: double.infinity,
      color: const Color(0xFFFF4FA0).withOpacity(0.15),
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          const Text(
            'Miku butuh izin "Akses Notifikasi" untuk bisa membaca & membalas chat.',
            style: TextStyle(color: Colors.white),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          ElevatedButton(
            onPressed: () async {
              await _notifications.openNotificationAccessSettings();
              final granted = await _notifications.hasNotificationAccess();
              setState(() => _notifAccessGranted = granted);
            },
            child: const Text('Aktifkan Sekarang'),
          ),
        ],
      ),
    );
  }
}
