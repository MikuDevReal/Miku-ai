import 'package:device_apps/device_apps.dart';

/// Mencari & membuka aplikasi terinstal berdasarkan nama yang diucapkan user,
/// contoh: "buka whatsapp", "buka youtube", "buka kamera".
class AppLauncherService {
  List<Application>? _cachedApps;

  Future<List<Application>> _getApps() async {
    _cachedApps ??= await DeviceApps.getInstalledApplications(
      includeAppIcons: false,
      includeSystemApps: true,
      onlyAppsWithLaunchIntent: true,
    );
    return _cachedApps!;
  }

  Future<void> refreshCache() async {
    _cachedApps = await DeviceApps.getInstalledApplications(
      includeAppIcons: false,
      includeSystemApps: true,
      onlyAppsWithLaunchIntent: true,
    );
  }

  /// Mengambil perintah mentah seperti "buka whatsapp" atau "tolong buka youtube",
  /// membersihkan kata pemicu, lalu mencocokkan sisanya ke nama aplikasi terinstal.
  /// Mengembalikan nama aplikasi yang berhasil dibuka, atau null jika tidak ketemu.
  Future<String?> openAppFromCommand(String rawCommand) async {
    final query = _extractAppName(rawCommand);
    if (query.isEmpty) return null;

    final apps = await _getApps();

    // 1) exact match (case-insensitive)
    for (final app in apps) {
      if (app.appName.toLowerCase() == query) {
        DeviceApps.openApp(app.packageName);
        return app.appName;
      }
    }

    // 2) contains match, pilih yang paling pendek namanya (paling spesifik)
    final candidates = apps
        .where((a) => a.appName.toLowerCase().contains(query) ||
            query.contains(a.appName.toLowerCase()))
        .toList()
      ..sort((a, b) => a.appName.length.compareTo(b.appName.length));

    if (candidates.isNotEmpty) {
      DeviceApps.openApp(candidates.first.packageName);
      return candidates.first.appName;
    }

    return null;
  }

  static const _triggerWords = [
    'tolong',
    'buka',
    'jalankan',
    'nyalakan',
    'buka aplikasi',
    'buka app',
    'open',
  ];

  String _extractAppName(String command) {
    var text = command.toLowerCase().trim();
    for (final word in _triggerWords) {
      text = text.replaceAll(word, '');
    }
    return text.trim();
  }
}
