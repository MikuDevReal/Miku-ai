import 'package:flutter/services.dart';

/// Mencari & membuka aplikasi terinstal berdasarkan nama yang diucapkan user,
/// contoh: "buka whatsapp", "buka youtube", "buka kamera".
///
/// Tidak pakai paket pihak ketiga (mis. device_apps) karena paket semacam itu
/// sering sudah tidak di-update dan tidak kompatibel dengan Android Gradle
/// Plugin versi baru (butuh "namespace" di build.gradle-nya, yang tidak
/// pernah ditambahkan pembuatnya). Sebagai gantinya, daftar aplikasi &
/// perintah buka aplikasi diambil langsung dari kode native Android
/// (MainActivity.kt) lewat MethodChannel yang sama dengan fitur notifikasi.
class AppLauncherService {
  static const _channel = MethodChannel('miku_ai/notifications');

  List<_InstalledApp>? _cachedApps;

  Future<List<_InstalledApp>> _getApps() async {
    if (_cachedApps != null) return _cachedApps!;

    final result = await _channel.invokeMethod<List<dynamic>>('listInstalledApps');
    _cachedApps = (result ?? [])
        .map((e) => _InstalledApp(
              appName: (e as Map)['appName'] as String? ?? '',
              packageName: e['packageName'] as String? ?? '',
            ))
        .where((a) => a.packageName.isNotEmpty)
        .toList();
    return _cachedApps!;
  }

  Future<void> refreshCache() async {
    _cachedApps = null;
    await _getApps();
  }

  /// Mengambil perintah mentah seperti "buka whatsapp" atau "tolong buka youtube",
  /// membersihkan kata pemicu, lalu mencocokkan sisanya ke nama aplikasi terinstal.
  /// Mengembalikan nama aplikasi yang berhasil dibuka, atau null jika tidak ketemu.
  Future<String?> openAppFromCommand(String rawCommand) async {
    final query = _extractAppName(rawCommand);
    if (query.isEmpty) return null;

    final apps = await _getApps();

    // 1) exact match (case-insensitive)
    for (final app in apps) {
      if (app.appName.toLowerCase() == query) {
        await _channel.invokeMethod('launchApp', {'package': app.packageName});
        return app.appName;
      }
    }

    // 2) contains match, pilih yang paling pendek namanya (paling spesifik)
    final candidates = apps
        .where((a) => a.appName.toLowerCase().contains(query) ||
            query.contains(a.appName.toLowerCase()))
        .toList()
      ..sort((a, b) => a.appName.length.compareTo(b.appName.length));

    if (candidates.isNotEmpty) {
      await _channel.invokeMethod('launchApp', {'package': candidates.first.packageName});
      return candidates.first.appName;
    }

    return null;
  }

  static const _triggerWords = [
    'tolong',
    'buka',
    'jalankan',
    'nyalakan',
    'buka aplikasi',
    'buka app',
    'open',
  ];

  String _extractAppName(String command) {
    var text = command.toLowerCase().trim();
    for (final word in _triggerWords) {
      text = text.replaceAll(word, '');
    }
    return text.trim();
  }
}

class _InstalledApp {
  final String appName;
  final String packageName;
  _InstalledApp({required this.appName, required this.packageName});
}
