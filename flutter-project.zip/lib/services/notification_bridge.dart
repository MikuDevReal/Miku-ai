import 'dart:async';
import 'package:flutter/services.dart';
import '../models/chat_message.dart';

/// Jembatan ke kode native Android (NotificationListenerService.kt).
///
/// - `notificationEvents` (EventChannel): stream notifikasi chat baru yang masuk
///   (WhatsApp, dll), ditangkap oleh NotificationListenerService lalu dikirim ke Flutter.
/// - `miku_ai/notifications` (MethodChannel): dipakai untuk cek/minta izin akses
///   notifikasi, dan mengirim balasan lewat quick-reply action milik notifikasi asli.
class NotificationBridge {
  static const _methodChannel = MethodChannel('miku_ai/notifications');
  static const _eventChannel = EventChannel('miku_ai/notifications_stream');

  Stream<ChatMessage>? _stream;

  /// Stream pesan chat baru. Berlangganan ini dari UI untuk update daftar chat
  /// & memicu Miku membacakan pesan yang masuk.
  Stream<ChatMessage> get onNewMessage {
    _stream ??= _eventChannel
        .receiveBroadcastStream()
        .map((event) => ChatMessage.fromMap(event as Map));
    return _stream!;
  }

  /// Apakah user sudah mengaktifkan "Notification Access" untuk Miku AI
  /// di Pengaturan > Aplikasi Notifikasi Khusus.
  Future<bool> hasNotificationAccess() async {
    final result =
        await _methodChannel.invokeMethod<bool>('hasNotificationAccess');
    return result ?? false;
  }

  /// Membuka halaman Pengaturan Android untuk mengaktifkan izin akses notifikasi.
  Future<void> openNotificationAccessSettings() async {
    await _methodChannel.invokeMethod('openNotificationAccessSettings');
  }

  /// Mengirim balasan suara (yang sudah diubah ke teks) melalui tombol
  /// "Balas Cepat" (RemoteInput) milik notifikasi asli, seolah-olah user
  /// mengetik balasan itu sendiri di WhatsApp.
  ///
  /// Mengembalikan true jika berhasil dikirim ke aplikasi target.
  Future<bool> sendReply({
    required int notificationId,
    required String appPackage,
    required String replyText,
  }) async {
    final result = await _methodChannel.invokeMethod<bool>('sendReply', {
      'id': notificationId,
      'package': appPackage,
      'text': replyText,
    });
    return result ?? false;
  }
}
