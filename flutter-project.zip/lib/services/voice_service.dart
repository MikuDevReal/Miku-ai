import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Membungkus speech-to-text (mendengarkan) dan text-to-speech (bicara)
/// dalam satu service supaya gampang dipakai dari UI.
class VoiceService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _speechAvailable = false;
  bool get isListening => _speech.isListening;
  bool get isReady => _speechAvailable;

  Future<bool> init() async {
    _speechAvailable = await _speech.initialize(
      onStatus: (status) => print('STT status: $status'),
      onError: (error) => print('STT error: $error'),
    );

    await _tts.setLanguage('id-ID');
    await _tts.setSpeechRate(0.48);
    await _tts.setPitch(1.05); // sedikit lebih tinggi, kesan "Miku"

    return _speechAvailable;
  }

  /// Mulai mendengarkan satu perintah/kalimat.
  /// [onResult] dipanggil dengan teks final setelah user selesai bicara.
  /// [onUnavailable] dipanggil (dan return value-nya false) kalau mic/STT
  /// tidak siap (biasanya karena izin RECORD_AUDIO belum diberikan), supaya
  /// UI pemanggil tidak "diam" tanpa penjelasan seperti sebelumnya.
  Future<bool> listenOnce({
    required void Function(String text) onResult,
    void Function(String partial)? onPartial,
    void Function(String reason)? onUnavailable,
  }) async {
    if (!_speechAvailable) {
      // Coba re-init sekali (mis. user baru saja mengaktifkan izin mic
      // lewat Settings lalu kembali ke app tanpa restart total).
      _speechAvailable = await _speech.initialize();
    }

    if (!_speechAvailable) {
      onUnavailable?.call(
        'Mic tidak aktif. Pastikan izin Mikrofon untuk Miku AI sudah diizinkan di Pengaturan.',
      );
      return false;
    }

    final started = await _speech.listen(
      localeId: 'id_ID',
      listenFor: const Duration(seconds: 12),
      pauseFor: const Duration(seconds: 3),
      onResult: (result) {
        if (onPartial != null) onPartial(result.recognizedWords);
        if (result.finalResult) {
          onResult(result.recognizedWords);
        }
      },
    );

    // Beberapa versi speech_to_text mengembalikan void, bukan bool -
    // started akan null pada kasus itu, jadi kita anggap sukses selama
    // tidak ada exception yang dilempar di atas.
    return started ?? true;
  }

  // ---- Ganti suara TTS ----

  /// Ambil daftar suara TTS yang tersedia di perangkat.
  /// [localeFilter] default hanya suara berbahasa Indonesia ("id"); kirim
  /// null untuk menampilkan semua suara yang ada di perangkat.
  Future<List<Map<String, String>>> getAvailableVoices({
    String? localeFilter = 'id',
  }) async {
    final dynamic raw = await _tts.getVoices;
    final result = <Map<String, String>>[];
    if (raw is! List) return result;

    for (final entry in raw) {
      if (entry is! Map) continue;
      final name = entry['name']?.toString() ?? '';
      final locale = entry['locale']?.toString() ?? '';
      if (name.isEmpty) continue;
      if (localeFilter == null ||
          locale.toLowerCase().contains(localeFilter.toLowerCase())) {
        result.add({'name': name, 'locale': locale});
      }
    }
    return result;
  }

  /// Set suara TTS yang dipakai. [voice] berupa map {'name': ..., 'locale': ...}
  /// yang didapat dari [getAvailableVoices].
  Future<void> setVoice(Map<String, String> voice) async {
    await _tts.setVoice({
      'name': voice['name'] ?? '',
      'locale': voice['locale'] ?? 'id-ID',
    });
  }

  Future<void> setPitch(double pitch) => _tts.setPitch(pitch);
  Future<void> setSpeechRate(double rate) => _tts.setSpeechRate(rate);

  Future<void> stopListening() async {
    await _speech.stop();
  }

  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> stopSpeaking() => _tts.stop();
}
