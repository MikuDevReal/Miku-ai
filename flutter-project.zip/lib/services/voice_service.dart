import 'dart:async';

import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Membungkus speech-to-text (mendengarkan) dan text-to-speech (bicara)
/// dalam satu service supaya gampang dipakai dari UI.
class VoiceService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _speechAvailable = false;
  bool get isListening => _speech.isListening;
  bool get isReady => _speechAvailable;

  // Callback sesi-berjalan, di-set ulang tiap listenOnce() dipanggil, supaya
  // status/error dari native speech recognizer bisa diteruskan ke UI -
  // sebelumnya ini cuma di-print() ke console dan UI tidak pernah tahu kalau
  // sesi mendengarkan berakhir tanpa hasil (makanya kelihatan "stuck").
  void Function(String status)? _onStatusChange;
  void Function(String error)? _onSpeechError;

  Future<bool> init() async {
    _speechAvailable = await _speech.initialize(
      onStatus: (status) {
        print('STT status: $status');
        _onStatusChange?.call(status);
      },
      onError: (error) {
        print('STT error: ${error.errorMsg}');
        _onSpeechError?.call(error.errorMsg);
      },
    );

    await _tts.setLanguage('id-ID');
    await _tts.setSpeechRate(0.48);
    await _tts.setPitch(1.05); // sedikit lebih tinggi, kesan "Miku"

    return _speechAvailable;
  }

  /// Mulai satu sesi mendengarkan, dan (BEDA dari sebelumnya) BENAR-BENAR
  /// menunggu sampai sesi itu selesai (dapat hasil final / error / timeout)
  /// sebelum Future ini selesai. Sebelumnya method ini kembali secepatnya
  /// setelah sesi dimulai, sementara hasilnya baru datang belakangan lewat
  /// callback - itu bikin kode pemanggil (terutama mode dengar-terus-menerus)
  /// gampang start sesi baru padahal sesi lama belum benar-benar berhenti.
  ///
  /// [onResult] dipanggil dengan teks final setelah user selesai bicara.
  /// [onUnavailable] dipanggil kalau mic/STT tidak siap sama sekali
  /// (biasanya izin RECORD_AUDIO belum diberikan).
  /// [onError] dipanggil kalau native speech recognizer melempar error di
  /// tengah sesi (mis. "error_no_match", "error_speech_timeout").
  Future<bool> listenOnce({
    required void Function(String text) onResult,
    void Function(String partial)? onPartial,
    void Function(String reason)? onUnavailable,
    void Function(String error)? onError,
  }) async {
    if (!_speechAvailable) {
      // Coba re-init sekali (mis. user baru saja mengaktifkan izin mic
      // lewat Settings lalu kembali ke app tanpa restart total).
      _speechAvailable = await _speech.initialize();
    }

    if (!_speechAvailable) {
      onUnavailable?.call(
        'Mic tidak aktif. Pastikan izin Mikrofon untuk Miku AI sudah diizinkan di Pengaturan.',
      );
      return false;
    }

    // Pastikan tidak ada sesi lama yang masih menggantung sebelum mulai baru.
    if (_speech.isListening) {
      await _speech.stop();
    }

    final completer = Completer<bool>();
    void finish(bool ok) {
      if (!completer.isCompleted) completer.complete(ok);
    }

    _onSpeechError = (err) {
      onError?.call(err);
      // Error biasanya diikuti status 'done' sesaat lagi, tapi beri jaring
      // pengaman kecil supaya tidak nyangkut kalau ternyata tidak diikuti.
      Future.delayed(const Duration(milliseconds: 300), () => finish(true));
    };
    _onStatusChange = (status) {
      if (status == 'done' || status == 'notListening') {
        finish(true);
      }
    };

    await _speech.listen(
      localeId: 'id_ID',
      listenFor: const Duration(seconds: 12),
      pauseFor: const Duration(seconds: 3),
      onResult: (result) {
        if (onPartial != null) onPartial(result.recognizedWords);
        if (result.finalResult) {
          onResult(result.recognizedWords);
          finish(true);
        }
      },
    );

    // Jaring pengaman terakhir: kalau entah kenapa tidak ada status/error/
    // hasil final yang pernah datang, jangan sampai nunggu selamanya.
    return completer.future.timeout(
      const Duration(seconds: 18),
      onTimeout: () async {
        await _speech.stop();
        return true;
      },
    );
  }

  // ---- Ganti suara TTS ----

  /// Ambil daftar suara TTS yang tersedia di perangkat.
  /// [localeFilter] default hanya suara berbahasa Indonesia ("id"); kirim
  /// null untuk menampilkan semua suara yang ada di perangkat.
  Future<List<Map<String, String>>> getAvailableVoices({
    String? localeFilter = 'id',
  }) async {
    final dynamic raw = await _tts.getVoices;
    final result = <Map<String, String>>[];
    if (raw is! List) return result;

    for (final entry in raw) {
      if (entry is! Map) continue;
      final name = entry['name']?.toString() ?? '';
      final locale = entry['locale']?.toString() ?? '';
      if (name.isEmpty) continue;
      if (localeFilter == null ||
          locale.toLowerCase().contains(localeFilter.toLowerCase())) {
        result.add({'name': name, 'locale': locale});
      }
    }
    return result;
  }

  /// Set suara TTS yang dipakai. [voice] berupa map {'name': ..., 'locale': ...}
  /// yang didapat dari [getAvailableVoices].
  Future<void> setVoice(Map<String, String> voice) async {
    await _tts.setVoice({
      'name': voice['name'] ?? '',
      'locale': voice['locale'] ?? 'id-ID',
    });
  }

  Future<void> setPitch(double pitch) => _tts.setPitch(pitch);
  Future<void> setSpeechRate(double rate) => _tts.setSpeechRate(rate);

  Future<void> stopListening() async {
    await _speech.stop();
  }

  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> stopSpeaking() => _tts.stop();
}
