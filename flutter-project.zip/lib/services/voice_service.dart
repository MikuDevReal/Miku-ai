import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Membungkus speech-to-text (mendengarkan) dan text-to-speech (bicara)
/// dalam satu service supaya gampang dipakai dari UI.
class VoiceService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _speechAvailable = false;
  bool get isListening => _speech.isListening;

  Future<bool> init() async {
    _speechAvailable = await _speech.initialize(
      onStatus: (status) => print('STT status: $status'),
      onError: (error) => print('STT error: $error'),
    );

    await _tts.setLanguage('id-ID');
    await _tts.setSpeechRate(0.48);
    await _tts.setPitch(1.05); // sedikit lebih tinggi, kesan "Miku"

    return _speechAvailable;
  }

  /// Mulai mendengarkan satu perintah/kalimat.
  /// [onResult] dipanggil dengan teks final setelah user selesai bicara.
  Future<void> listenOnce({
    required void Function(String text) onResult,
    void Function(String partial)? onPartial,
  }) async {
    if (!_speechAvailable) return;

    await _speech.listen(
      localeId: 'id_ID',
      listenFor: const Duration(seconds: 12),
      pauseFor: const Duration(seconds: 3),
      onResult: (result) {
        if (onPartial != null) onPartial(result.recognizedWords);
        if (result.finalResult) {
          onResult(result.recognizedWords);
        }
      },
    );
  }

  Future<void> stopListening() async {
    await _speech.stop();
  }

  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> stopSpeaking() => _tts.stop();
}
