import 'package:flutter/material.dart';
import '../models/chat_message.dart';

class ChatBubble extends StatelessWidget {
  final ChatMessage message;
  final VoidCallback onReplyTap;

  const ChatBubble({
    super.key,
    required this.message,
    required this.onReplyTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF10233B),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF35D0FF).withOpacity(0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.chat_bubble, color: Color(0xFF35D0FF), size: 16),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  '${message.sender} • ${message.appName}',
                  style: const TextStyle(
                    color: Color(0xFF35D0FF),
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            message.text,
            style: const TextStyle(color: Colors.white, fontSize: 14),
          ),
          if (message.canReply) ...[
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: onReplyTap,
                icon: const Icon(Icons.mic, size: 16, color: Color(0xFFFF4FA0)),
                label: const Text(
                  'Balas dengan suara',
                  style: TextStyle(color: Color(0xFFFF4FA0)),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
